export default [
  {
    title: 'Dashboard Alpha',
    key: 'dashboardAlpha',
    url: '/admin/dashboard',
    icon: 'icmn icmn-stack',
  },
  {
    title: 'Empty Page',
    key: 'empty',
    url: '/empty',
    icon: 'icmn icmn-books',
  },
  {
    title: 'Organization Page',
    key: 'Organization',
    url: '/admin/organization',
    icon: 'icmn icmn',
  },
]
