module.exports = {
    setting: {
        realm: 'master',
        serverUrl: 'http://localhost:8080',
        resource: 'security-admin-console',
        adminLogin: 'admin',
        adminPassword: 'admin',
        adminClienId: 'security-admin-console',
    },
    client: {
        id: 'realclient',
        secret: '374e3557-9e09-42ec-9474-827085e48776'
    }
};